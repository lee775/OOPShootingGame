#pragma once

#define BASE_OBJECT 0x1
#define PLAYER_OBJECT 0x2
#define MONSTER_OBJECT 0x3
#define BULLET_OBJECT 0x4
#define BOSS_OBJECT 0x5
#define SKILL_BULLET_OBJECT 0x6

#include <Windows.h>
#pragma comment(lib, "Winmm.lib")

//#include "BaseObject.h"
//#include "MyList.h"
//#include "Singleton.h"
//#include "GameManager.h"
//#include "ScreenBuffer.h"
//#include "Console.h"
//#include "MonsterInfo.h"
//#include "Player.h"
//#include "Monster.h"
//#include "Bullet.h"
//#include "Stage.h"