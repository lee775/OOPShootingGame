#include "Selector.h"

Selector::Selector(int defaultY) : _icon1(L'>'), _icon2(L' '), _currentIcon(L'>'), _iconChangeFrame(20), _currentFrame(20), _seletorMoveFrame(5), _currentMoveFrame(0), _selectorY(defaultY)
{
}
